var express = require('express');
var router = express.Router();
var db = require('../db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.title == undefined || req.query.title == null || req.query.title.trim() == '') {

        query = 'SELECT city FROM movies GROUP BY city';
    }
    else {
       if(req.query.venue == undefined || req.query.venue == null || req.query.venue.trim() == ''){
         query = 'SELECT city FROM movies WHERE title LIKE "%' + req.query.title + '%" GROUP BY city';
        }else{
          query = 'SELECT * FROM movies WHERE title LIKE "%' + req.query.title + '%" AND venue LIKE "%' + req.query.venue + '%"';
        }
    }

    db.select(query, res);

});

module.exports = router;
