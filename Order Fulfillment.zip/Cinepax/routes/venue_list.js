var express = require('express');
var router = express.Router();
let db = require('../db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.city == undefined || req.query.city == null || req.query.city.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "city parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.title == undefined || req.query.title == null || req.query.title.trim() == '') {

        query = 'SELECT venue FROM movies WHERE city LIKE "'+ req.query.city + '"';
    }
    else {

        query = 'SELECT id,venue,show_time FROM movies WHERE title LIKE "' + req.query.title + '" AND city LIKE "' + req.query.city + '" ';
    }

    db.select(query, res);

});

module.exports = router;
