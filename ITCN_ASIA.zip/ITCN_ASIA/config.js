exports.config = {
    mysql      : {
        host            : "52.89.22.214",
        user            : "arslan",
        password        : "root1122",
        database        : "itcn_db",
        connectionLimit : 50
    },
    errorCodes : {
        connectionError    : 101,
        connectionNotFound : 102,
        queryError         : 103,
        paramsMissing: 104
    }
};