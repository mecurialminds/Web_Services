var express = require('express');
var router = express.Router();
var db = require('../db');
/* GET home page. */
router.get('/', function(req, res, next) {

    var query = 'SELECT title,trailer,image_url,imdb_link FROM movies GROUP BY title,trailer,image_url,imdb_link';
     db.select(query,res);

});

module.exports = router;
