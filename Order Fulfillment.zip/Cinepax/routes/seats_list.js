var express = require('express');
var router = express.Router();
let db = require('../db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.id == undefined || req.query.id == null || req.query.id.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "id parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.date == undefined || req.query.date == null || req.query.date.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "date parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.row == undefined || req.query.row == null || req.query.row.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }
    var selectedRow = req.query.row.trim().toUpperCase();


    query = 'SELECT seat_number FROM tickets WHERE movie_id = ' + req.query.id + ' AND show_date LIKE "' + req.query.date + '" AND seat_number LIKE "' + selectedRow + '%"';


   db.returnSeats(query, selectedRow, res);


});


module.exports = router;
