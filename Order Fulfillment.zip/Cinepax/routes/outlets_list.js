var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');
/* GET home page. */
router.get('/', function(req, res, next) {

    let query = 'SELECT title, image_url,address FROM outlets';
    db.select(query,res);

});

module.exports = router;