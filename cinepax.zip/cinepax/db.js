var mysql = require('mysql');

this.select = function (query, res) {


    var con = mysql.createConnection({
        host: "127.0.0.1",
        user: "admin",
        password: "some_pass",
        database: "cineplax"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;
            var resultObj = {};
            resultObj.resultList = result;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

this.insert = function (query, res) {


    var con = mysql.createConnection({
        host: "127.0.0.1",
        user: "admin",
        password: "some_pass",
        database: "cineplax"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;
            var resultObj = {};
            resultObj.status = "success";
            resultObj.resultList = result;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

this.returnSeats = function (query, selectedRow, res) {


    var con = mysql.createConnection({
        host: "127.0.0.1",
        user: "admin",
        password: "some_pass",
        database: "cineplax"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;

            var seatsList = [];
            for (var i = 1; i < 17; i++) {
                seatsList.push(selectedRow + '-' + i);
            }

            for (var i = 0; i < result.length; i++) {
                var index = seatsList.indexOf(result[i].seat_number);
                if (index > -1) {
                    seatsList.splice(index, 1);
                }
            }

            var resultObj = {};
            resultObj.resultList = seatsList;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

module.exports = this;