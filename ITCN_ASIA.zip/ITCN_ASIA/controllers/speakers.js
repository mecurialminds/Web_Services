let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences'),
    _this                = this;

exports.getSpeakers = function (req, res) {
    let alias    = req.params.alias,
        track_id = req.query.track_id,
        event_id = req.query.event_id,
        query;
    if (alias && track_id) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `SELECT first_name, middle_name, last_name, title, organization, avatar FROM speakers WHERE conference_id = ${data.data.id} and track_id=${track_id}`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        if (alias && event_id) {
            conferenceController.getConferenceById(alias, (data) => {
                if (data.success) {
                    query = `SELECT id, title, avatar FROM speakers WHERE conference_id = ${data.data.id} and track_id=${track_id}`;
                    query = `SELECT first_name, middle_name, last_name, title, organization FROM speakers WHERE speakers.id IN (select speaker_id from event_speaker where event_id = ${event_id})`;

                    console.log(query);
                    db.readOperation(query, (data) => {
                        if (data.success) {
                            res.json(data);
                        } else res.json(data);
                    });
                } else {
                    res.json(data);
                }
            });
        }else{
            res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
        }

    }
};