let config      = require('./../config').config,
    mysql       = require('mysql'),
    mysqlConfig = config.mysql,
    pool        = mysql.createPool(mysqlConfig);

let getConnection = (cb) => {
    if (pool) {
        pool.getConnection(function (err, connection) {
            cb(err, connection);
        });
    }
    else {
        cb(new Error('pool_undefined'), null);
    }
};

exports.getConnection = getConnection;

exports.readOperation = (query, cb) => {
    getConnection(function (err, conn) {
        if (err) {
            console.error("[db][readOperation][Connection][Error]", err);
            return cb({
                success   : false,
                error     : err,
                errorCode : config.errorCodes.connectionError,
                msg       : "Failed to connect database."
            });
        }
        else if (!conn) {
            console.info("[db][readOperation][No Connection]");
            return cb({
                success   : false,
                errorCode : config.errorCodes.connectionNotFound,
                msg       : "Failed to connect database."
            });
        }
        else {
            conn.query(query, function (err, records, fields) {
                if (err) {
                    console.info("[db][readOperation][Query]");
                    return cb({
                        success   : false,
                        error     : err,
                        errorCode : config.errorCodes.queryError,
                        msg       : "Invalid query."
                    });
                    conn.release();
                    return cb({
                        success : false,
                        msg     : err
                    });
                } else {
                    conn.release();
                    return cb({
                        success : true,
                        data : records
                    });
                }
            });
        }
    });
};