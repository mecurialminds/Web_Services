let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences'),
    _this                = this;

exports.getSessions = function (req, res) {
    let alias      = req.params.alias,
        event_type = req.query.event_type,
        track_id   = req.query.track_id,
        query;
    if (alias && event_type && track_id) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `SELECT id, name, url, start_at, end_at, place FROM events WHERE conference_id = ${data.data.id} and event_type='${event_type}' and track_id=${track_id}`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};
