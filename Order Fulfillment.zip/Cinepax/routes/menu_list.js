var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.postback == undefined || req.query.postback == null || req.query.postback.trim() == '') {

        query = 'SELECT id, menu FROM restaurant GROUP BY menu';
    }
    else {

        query = 'SELECT id, menu FROM restaurant WHERE postback LIKE "' + req.query.postback + '" GROUP BY menu';
    }

    db.select(query, res);

});

module.exports = router;