var express = require('express');
var router = express.Router();
var db = require('../db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.id == undefined || req.query.id == null || req.query.id.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "id parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.date == undefined || req.query.date == null || req.query.date.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "date parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.seat == undefined || req.query.seat == null || req.query.seat.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.price == undefined || req.query.price == null || req.query.price.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }
    var selectedSeat = req.query.seat.trim().toUpperCase();
    var selectedDate = req.query.date.trim();
    var selectedMovieId = req.query.id.trim()
    var selectedPrice = req.query.price.trim()

    query = 'INSERT INTO tickets (movie_id, seat_number, show_date, price) VALUES(' + selectedMovieId + ',"' + selectedSeat + '","' + selectedDate + '",' + selectedPrice + ')';
    //query = 'SELECT seat_number FROM tickets WHERE movie_id = ' + req.query.id + ' AND show_date LIKE "' + req.query.date + '" AND seat_number LIKE "' + selectedRow + '%"';

    db.insert(query, res);
    //db.returnSeats(query, selectedRow, res);


});


module.exports = router;
