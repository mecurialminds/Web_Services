var mysql = require('mysql');

this.select = function (query, res) {


    var con = mysql.createConnection({
        //host: "192.168.227.140",
        host: "localhost",
        user: "admin",
        password: "mysql",
        database: "cineplax"
        //port: "3306"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;
            var resultObj = {};
            resultObj.resultList = result;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

this.insert = function (query, res) {


    var con = mysql.createConnection({
        host: "192.168.227.140",
        user: "admin",
        password: "some_pass",
        database: "cineplax"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;
            var resultObj = {};
            resultObj.status = "success";
            resultObj.resultList = result;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

this.returnSeats = function (query, selectedRow, res) {


    var con = mysql.createConnection({
        host: "192.168.227.140",
        user: "admin",
        password: "some_pass",
        database: "cineplax"
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(query, function (err, result, fields) {
            if (err) throw err;

            var seatsList = [];
            for (let i = 1; i < 21; i++) {
                seatsList.push(selectedRow + '-' + i);
            }

            for (let i = 0; i < result.length; i++) {
                var index = seatsList.indexOf(result[i].seat_number);
                if (index > -1) {
                    seatsList.splice(index, 1);
                }
            }

            var resultObj = {};
            resultObj.resultList = seatsList;
            res.send(resultObj);
            //console.log(result);
        });
    });
}

module.exports = this;