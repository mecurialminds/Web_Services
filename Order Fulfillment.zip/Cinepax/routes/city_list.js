var express = require('express');
var router = express.Router();
let db = require('../db');
/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.title == undefined || req.query.title == null || req.query.title.trim() == '') {

        query = 'SELECT city FROM movies GROUP BY city';
    }
    else {

        query = 'SELECT city FROM movies WHERE title LIKE "' + req.query.title + '" GROUP BY city';
    }

    db.select(query, res);

});

module.exports = router;
