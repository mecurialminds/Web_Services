var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');

/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);

    if (req.query.order_id == undefined || req.query.order_id == null || req.query.order_id.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "id parameter is missing!";
        res.send(err);
        return;
    }

    if (req.query.date == undefined || req.query.date == null || req.query.date.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "date parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.address == undefined || req.query.address == null || req.query.address.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }
    if (req.query.items == undefined || req.query.items == null || req.query.items.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }

    if (req.query.item_Qty == undefined || req.query.item_Qty == null || req.query.item_Qty.trim() == '') {
        var err = {};
        err.status = "Error";
        err.msg = "row parameter is missing!";
        res.send(err);
        return;
    }

    var address = req.query.address.trim();
    var selectedDate = req.query.date.trim();
    var order_id = req.query.order_id.trim();
    var order_items = req.query.items.trim();
    var items_Qty = req.query.item_Qty.trim();

    query = 'INSERT INTO orders (order_id, address, items, item_Qty, date) VALUES(' + order_id + ',"' + address + '","' + order_items + '","' + items_Qty + '",' + selectedDate + ')';

    db.insert(query, res);
});

module.exports = router;