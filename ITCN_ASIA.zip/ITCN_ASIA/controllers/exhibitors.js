let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences'),
    moment               = require('moment'),
    md5                  = require('md5'),
    _this                = this;

exports.getExhibitors = function (req, res) {
    let alias    = req.params.alias,
        track_id = req.query.track_id,
        query;
    if (alias && track_id) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `SELECT id, name, organization, stall_no, avatar FROM exhibitors WHERE conference_id = ${data.data.id} and track_id=${track_id}`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};

exports.login = (req, res) => {
    let alias    = req.params.alias,
        email    = req.body.email,
        password = req.body.password,
        query;
    if (alias && email && password) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `SELECT * FROM exhibitors WHERE conference_id = ${data.data.id} and email='${email}' and password = '${password}'`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        if (data.data.length > 0) {
                            res.json({success : true, msg : "Successfully loggedIn."});
                        } else res.json({success : false, msg : "Invalid credentials."});
                    } else res.json(data);
                });
            } else res.json(data);
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};

exports.addExhibitor = (req, res) => {
    let alias     = req.params.alias,
        name      = req.body.name,
        trackId   = Number(req.body.track_id),
        org       = req.body.org,
        country   = req.body.country,
        email     = req.body.email,
        password  = req.body.password,
        startDate = Number(req.body.startDate),
        endDate   = Number(req.body.endDate),
        exhibitorDetails   = req.body.exhibitorDetails,
        productCategory   = req.body.productCategory,
        query;
    if (alias && name && trackId && org && country && password && startDate && endDate) {
        conferenceController.getConferenceById(alias, (data) => {
            let conference_id = data.data.id;
            if (data.success) {
                query = "SELECT MAX(stall_no) as stall_no FROM exhibitors";
                db.readOperation(query, (data) => {
                    if (data.success) {
                        let stall_no = data.data[0].stall_no;
                        stall_no = '404'; // 404 code for stall not allocated to unverified users.
                        startDate   = moment(startDate).format('YYYY-MM-DD HH:mm:ss');
                        endDate     = moment(endDate).format('YYYY-MM-DD HH:mm:ss');
                        query       = `INSERT INTO exhibitors(name, organization, country, startDate, endDate, conference_id, email, track_id , password, stall_no, exhibitorDetails, productCategory) VALUES ('${name}', '${org}', '${country}', '${startDate}', '${endDate}', ${conference_id}, '${email}', ${trackId}, '${md5(password)}', '${stall_no}','${exhibitorDetails}','${productCategory}')`;
                        console.log(query);
                        db.readOperation(query, (data) => {
                            if (data.success) {
                                if (data.data.affectedRows) {
                                    res.json({success : true, msg : "Exhibitor add successfully."});
                                } else res.json({success : false, msg : "Fail to insert Exhibitor."});
                            } else res.json(data);
                        });
                    } else {

                    }
                });
            } else res.json(data);
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};