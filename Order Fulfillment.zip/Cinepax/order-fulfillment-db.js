var mysql = require('mysql');

this.insert = function (query, res) {


    var con = mysql.createConnection({
        // host: "192.168.227.140",
        host: "localhost",
        user: "admin",
        password: "mysql",
        database: "orderfulfillment"
    });

    con.connect(function(err) {
        if (err) throw err;
        con.query(query, function (err, result) {
            if (err) throw err;
            console.log("1 record inserted, ID: " + result.insertId);
        });
    });

}

this.select = function (query, res) {

	console.log('In DB 1');
    var con = mysql.createConnection({
        //host: "192.168.227.140",
        host: "localhost",
        user: "admin",
        password: "mysql",
        database: "orderfulfillment"
        //port: "3306"
    });
	console.log('In DB 2');
    con.connect(function (err) {
		console.log('In DB 3');
        if (err) throw err;
        con.query(query, function (err, result, fields) {
			console.log('In DB 4' + err);
            if (err) throw err;
			console.log('In DB 5');
            var resultObj = {};
			console.log('Result = ' + result);
            resultObj.resultList = result;
            res.send(resultObj);
            console.log(result);
        });
    });
}