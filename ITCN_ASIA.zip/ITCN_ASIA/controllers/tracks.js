let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences'),
    _this                = this;

exports.getTracks = function (req, res) {
    let alias = req.params.alias,
        query;
    if (alias) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `SELECT id, name FROM event_tracks WHERE conference_id = '${data.data.id}'`;
                db.readOperation(query, (data) => {
                    if (data.success) {
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};
