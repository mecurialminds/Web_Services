var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');
/* GET home page. */
router.get('/', function(req, res, next) {
	console.log('In Cuisine List');
    let query = 'SELECT cuisine, image_url, postback FROM restaurant GROUP BY cuisine, image_url';
    db.select(query,res);

});

module.exports = router;