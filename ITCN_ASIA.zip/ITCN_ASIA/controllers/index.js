let express = require('express'),
    router  = express.Router();

router.use(function timeLog(req, res, next) {
    console.log('API HIT TIME ', Date.now());
    next()
});

router.get('/', function (req, res) {
    res.render('index', {title : 'Express'});
});

let usersController      = require('./users'),
    conferenceController = require('./conferences'),
    tracksController     = require('./tracks'),
    sessionsController   = require('./sessions'),
    speakerController    = require('./speakers'),
    subscriberController = require('./subscribers'),
    exhibitorsController = require('./exhibitors'),
    qrCodeController     = require('./qrcode');

router.get('/users', usersController.getUsers);
router.get('/:alias/conferences', conferenceController.getConference);
router.get('/:alias/tracks', tracksController.getTracks);
router.get('/:alias/sessions', sessionsController.getSessions);
router.get('/:alias/exhibitors', exhibitorsController.getExhibitors);
router.post('/:alias/addExhibitor', exhibitorsController.addExhibitor);
router.get('/:alias/speakers', speakerController.getSpeakers);
router.post('/:alias/login', exhibitorsController.login);
router.post('/:alias/scanCode', qrCodeController.scanCodes);
router.get('/:alias/subscribers', subscriberController.getSubscribers);
router.get('/:alias/updateSubscriber', subscriberController.updateSubscriber);
router.get('/:alias/addSubscriber', subscriberController.addSubscriber);

module.exports = router;