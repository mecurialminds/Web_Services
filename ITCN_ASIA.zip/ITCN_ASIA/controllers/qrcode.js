let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences'),
    _this                = this;
exports.scanCodes        = (req, res) => {
    let alias = req.params.alias,
        email = req.body.email,
        code  = req.body.code,
        query;
    if (alias && email && code) {
        query = `INSERT INTO scancodes(email, code) VALUES ('${email}', '${code}')`;
        console.log(query);
        db.readOperation(query, (data) => {
            if (data.success) {
                if (data.data.affectedRows) {
                    res.json({success : true, msg : "Code inserted successfully."});
                } else res.json({success : false, msg : "Fail to insert code."});
            } else res.json(data);
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};