let db     = require('./../models/db'),
    config = require('./../config').config,
    _this  = this;

exports.getConferenceById = function (alias, cb) {
    let query = `SELECT * FROM conferences WHERE alias = '${alias}'`;
    db.readOperation(query, (data) => {
        if (data.success) {
            data.data = data.data.length > 0 ? data.data[0] : {};
            cb(data);
        } else cb(data);
    });
};

exports.getConference = function (req, res) {
    let alias = req.params.alias,
        query;
    if (alias) {
        _this.getConferenceById(alias, (data) => {
            res.json(data);
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};
