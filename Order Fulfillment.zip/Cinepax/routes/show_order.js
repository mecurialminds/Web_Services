var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');
/* GET home page. */
router.get('/', function(req, res, next) {

    let query = 'SELECT * FROM orders';
    db.select(query,res);

});

module.exports = router;