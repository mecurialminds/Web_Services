let db                   = require('./../models/db'),
    config               = require('./../config').config,
    conferenceController = require('./../controllers/conferences');

exports.getSubscribers = function (req, res) {
    let alias = req.params.alias,
        query;
    if (alias) {
        query = `SELECT * FROM fb_subscribers where sub = 1`;
        console.log(query);
        db.readOperation(query, (data) => {
            if (data.success) {
                res.json(data);
            } else res.json(data);
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};


exports.updateSubscriber = function (req, res) {
    let alias  = req.params.alias,
        userId = req.query.user_id,
        query;
    if (alias && userId) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `UPDATE fb_subscribers SET sub = 0 where user_id = '${userId}'`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        data.msg = "Subscriber details updated successfully.";
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};

exports.addSubscriber = function (req, res) {
    let alias  = req.params.alias,
        userId = req.query.user_id,
        sub    = req.query.sub ? req.query.sub : 1,
        query;
    if (alias && userId && (sub == 0 || sub == 1)) {
        conferenceController.getConferenceById(alias, (data) => {
            if (data.success) {
                query = `INSERT INTO fb_subscribers(user_id, sub) VALUES('${userId}', ${sub})`;
                console.log(query);
                db.readOperation(query, (data) => {
                    if (data.success) {
                        data.msg = "Subscriber added successfully.";
                        res.json(data);
                    } else res.json(data);
                });
            } else {
                res.json(data);
            }
        });
    } else {
        res.json({success : false, msg : "Request params are missing.", errorCode : config.errorCodes.paramsMissing});
    }
};