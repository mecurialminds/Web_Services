var express = require('express');
var router = express.Router();
let db = require('../db');
/* GET home page. */
router.get('/', function(req, res, next) {

    let query = 'SELECT title FROM movies GROUP BY title';
     db.select(query,res);

});

module.exports = router;
