var express = require('express');
var router = express.Router();
let db = require('../order-fulfillment-db');

/* GET home page. */
router.get('/', function (req, res, next) {
    var query = '';
    console.log(req.query);
    if (req.query.id == undefined || req.query.id == null) {

        if (req.query.title == undefined || req.query.title == null) {

            //query = 'SELECT id, menu FROM restaurant GROUP BY menu';
        }else{
            query = 'SELECT title, description FROM menu WHERE title LIKE "' + req.query.title + '"';
        }
    }
    else {

        query = 'SELECT id, title, image_url, description FROM menu WHERE restaurant_id LIKE "' + req.query.id + '"';
    }

    db.select(query, res);

});

module.exports = router;