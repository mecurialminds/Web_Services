exports.getUsers = function (req, res) {
    res.json({success : true, data : []});
};
